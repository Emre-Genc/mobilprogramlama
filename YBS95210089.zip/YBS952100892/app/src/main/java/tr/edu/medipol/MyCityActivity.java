package tr.edu.medipol;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;

public class MyCityActivity extends AppCompatActivity {
    Button button10;
    Button button9;
    Button button8;
    Button button7;
    Button button6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_city);
        button10 = findViewById(R.id.button10);
        button9 = findViewById(R.id.button9);
        button8 = findViewById(R.id.button8);
        button7 = findViewById(R.id.button7);
        button6 = findViewById(R.id.button6);


        button10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent intent = new Intent(Intent.ACTION_VIEW);
               intent.setData(Uri.parse("https://www.yalova.bel.tr/tarihi-merkez/ibrahim-muteferrika-kagit-muzesi/7"));
                startActivity(intent);


            }
        });

        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.yalova.bel.tr/tarihi-merkez/yuruyen-kosk/1"));
                startActivity(intent);

            }
        });

        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.seyyahcelebi.com.tr/yalova-deprem-aniti.html"));
                startActivity(intent);
            }
        });

        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.yalova.bel.tr/tarihi-merkez/yalova-kent-muzesi/8"));
                startActivity(intent);

            }
        });

        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://www.yalova.bel.tr/tarihi-merkez/arboterum-canli-agac-muzesi/4"));
                startActivity(intent);

            }
        });


    }

        }




