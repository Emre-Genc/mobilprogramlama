package tr.edu.medipol;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import android.widget.Toast;

import javax.security.auth.Subject;

public class MainActivity extends AppCompatActivity {
    Button btn;
    Button btnn;
    Button btnCall;
    Button Eposta;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnCall= findViewById(R.id.btnCall);
        Eposta = findViewById(R.id.Eposta);




        tanimlama();
        tanimlamaa();

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent CoursesActiv = new Intent(getApplicationContext(),CoursesActivity.class);
                startActivity(CoursesActiv);

            }
        });

        btnn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent MyCityActiv = new Intent(getApplicationContext(),MyCityActivity.class);
                startActivity(MyCityActiv);
            }
        });

        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialPhoneNumber(btnCall.getText().toString());
            }
        });

        Eposta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String [] addresses = new String [1];
                addresses [0] = Eposta.getText().toString();
                composeEmail(addresses,"hello");
            }
        });




    }

    public void composeEmail(String[] addresses, String subject) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_EMAIL, addresses);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);


            startActivity(intent);
        }

    public void dialPhoneNumber(String phoneNumber) {
        Intent intent = new Intent(Intent.ACTION_DIAL);
        intent.setData(Uri.parse("tel:" + phoneNumber));
            startActivity(intent);
        }


    public void tanimlama(){
        btn=findViewById(R.id.CoursesAc);
    }
    public void tanimlamaa(){
        btnn=findViewById(R.id.MycityAc);
    }
}