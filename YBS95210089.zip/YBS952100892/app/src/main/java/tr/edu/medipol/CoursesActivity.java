package tr.edu.medipol;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;


public class CoursesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_courses);

        ListView listemiz = findViewById(R.id.listemiz);

        ArrayList<String> arrayList = new ArrayList<String>();

        arrayList.add("veri tabanı");
        arrayList.add("Pazarlama İlkeleri");
        arrayList.add("Dijital pazarlama");
        arrayList.add("Sistem analizi");
        arrayList.add("Mesleki İngilizce I");
        arrayList.add("mobil Programlama");
        arrayList.add("İşletmelerde Nicel Karar Verme Yöntemleri");

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,
                arrayList);
        listemiz.setAdapter(arrayAdapter);
        listemiz.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                Toast.makeText(CoursesActivity.this,arrayList.get(position), Toast.LENGTH_SHORT).show();
            }
        });



            }




    }
